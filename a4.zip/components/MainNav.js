import { Container, Nav, Navbar, Button, Form } from "react-bootstrap"
import { useState } from 'react';
import { useRouter } from "next/router";
import Link from "next/link"

export default function MainNav() {
    const [searchValue, setSearchValue] = useState('');
    const router = useRouter();

    function formSubmit(e) {
        e.preventDefault();
        router.push(`/artwork?title=true&q=${searchValue}`);
    }

    return (
        <>
        <Navbar bg="light" expand="lg" className="fixed-top">
            <Container>
                <Navbar.Brand>Connor Squires</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="me-auto">
                        <Link href="/" passHref legacyBehavior><Nav.Link>Home</Nav.Link></Link>
                        <Link href="/search" passHref legacyBehavior><Nav.Link>Advanced Search</Nav.Link></Link>
                    </Nav>
                </Navbar.Collapse>
            </Container>
            <Form className="d-flex" onSubmit={formSubmit}>
            <Form.Control
              type="search"
              placeholder="Search"
              className="me-2"
              aria-label="Search"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
            />
            <Button type="submit">Search</Button>
          </Form>
        </Navbar>
        <br />
        <br />
        </>
    );
}